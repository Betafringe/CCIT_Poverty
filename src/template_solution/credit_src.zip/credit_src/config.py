#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2018/5/3 21:32
# @Author  : Betafringe
# @Site    : 
# @File    : config.py
# @Software: PyCharm


def origin_sql_settings():
    origin_sql_args = {
        'ip': '192.168.56.142',
        'port': 3306,
        'user': 'poor',
        'password': 'password_poor',
        'db': 'initial',
    }
    return origin_sql_args


def update_sql_settings():
    update_sql_args = {
        'ip': '192.168.56.142',
        'port': 3306,
        'user': 'poor',
        'password': 'password_poor',
        'db': 'initial',
    }
    return update_sql_args


